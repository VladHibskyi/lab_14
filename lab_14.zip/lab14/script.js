// Task 1
let cities = ["Ternopil", "Lviv", "Warsaw"];
let result1 = cities.join("*");
console.log("Task 1 Result:", result1);

// Task 2 for loop
let numbers = [2, 3, 4, 5];
let product = 1;
for (let i = 0; i < numbers.length; i++) {
    product *= numbers[i];
}
console.log("Task 2 (for) Result:", product);

//while loop
let j = 0;
product = 1;
while (j < numbers.length) {
    product *= numbers[j];
    j++;
}
console.log("Task 2 (while) Result:", product);

// Task 3
function findMin() {
    let min = arguments[0];
    for (let i = 1; i < arguments.length; i++) {
        if (arguments[i] < min) {
            min = arguments[i];
        }
    }
    return min;
}
console.log("Task 3 Result:", findMin(12, 14, 4, -4, 0.2));

// Task 4
function findUnique(arr) {
    let uniqueSet = new Set(arr);
    return uniqueSet.size === arr.length;
}
console.log("Task 4 Result:", findUnique([1, 2, 3, 5, 3]));
console.log("Task 4 Result:", findUnique([1, 2, 3, 5, 11]));

// Task 5
class Purchase {
    constructor(name, quantity, purchased) {
      this.name = name;
      this.quantity = quantity;
      this.purchased = purchased;
    }
  }

  let shoppingList = [];

  function printShoppingList() {
    let unpurchasedItems = shoppingList.filter(item => !item.purchased);
    let purchasedItems = shoppingList.filter(item => item.purchased);

    let combinedList = unpurchasedItems.concat(purchasedItems);

    console.log("Список покупок:");
    combinedList.forEach(item => {
      console.log(`${item.name} - ${item.quantity} ${item.purchased ? "(куплений)" : "(не куплений)"}`);
    });
  }

  function addPurchase(name, quantity) {
    let existingItem = shoppingList.find(item => item.name === name);
    if (existingItem) {
      existingItem.quantity += quantity;
    } else {
      shoppingList.push(new Purchase(name, quantity, false));
    }
  }

  function purchaseProduct(name) {
    let existingItem = shoppingList.find(item => item.name === name);
    if (existingItem) {
      existingItem.purchased = true;
    } else {
      console.log("Товар не знайдено у списку покупок.");
    }
  }

  // Тестування
  addPurchase("Яблука", 2);
  addPurchase("Банани", 1);
  addPurchase("Яблука", 3);
  addPurchase("Огірки", 6);
  purchaseProduct("Яблука");
  purchaseProduct("Огірки");

  printShoppingList();
